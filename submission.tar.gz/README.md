# Jumping Cat video game time thing!!!

This is a video game with a jumping cat! You jump on platforms that slowly fall away beneath you until you either fall and meet your demise or reach the top and win!

Once you start the game, you (cat) will be sitting on the bottom of the screen. You can move left and right, and then hit A, B, or START to begin jumping! Once you begin jumping you can't stop until you win or lose, so be careful!

This game is heavily inspired by the mobile game doodle jump!

## Controls
- START - Begins game / Begins jumping 
- SELECT - Resets game to title screen 
- A/B/Up - Begins jumping 
- Left - Moves left 
- Right - Moves right 