/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 playersprite playersprite.png 
 * Time-stamp: Saturday 04/02/2022, 06:34:08
 * 
 * Image Information
 * -----------------
 * playersprite.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYERSPRITE_H
#define PLAYERSPRITE_H

extern const unsigned short playersprite[100];
#define PLAYERSPRITE_SIZE 200
#define PLAYERSPRITE_LENGTH 100
#define PLAYERSPRITE_WIDTH 10
#define PLAYERSPRITE_HEIGHT 10

#endif

