/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 splash60 splash60.png 
 * Time-stamp: Saturday 04/02/2022, 05:16:16
 * 
 * Image Information
 * -----------------
 * splash60.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPLASH60_H
#define SPLASH60_H

extern const unsigned short splash60[38400];
#define SPLASH60_SIZE 76800
#define SPLASH60_LENGTH 38400
#define SPLASH60_WIDTH 240
#define SPLASH60_HEIGHT 160

#endif

