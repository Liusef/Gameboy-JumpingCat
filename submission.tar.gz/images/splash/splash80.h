/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 splash80 splash80.png 
 * Time-stamp: Saturday 04/02/2022, 05:16:23
 * 
 * Image Information
 * -----------------
 * splash80.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPLASH80_H
#define SPLASH80_H

extern const unsigned short splash80[38400];
#define SPLASH80_SIZE 76800
#define SPLASH80_LENGTH 38400
#define SPLASH80_WIDTH 240
#define SPLASH80_HEIGHT 160

#endif

