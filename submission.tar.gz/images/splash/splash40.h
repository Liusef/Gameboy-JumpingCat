/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 splash40 splash40.png 
 * Time-stamp: Saturday 04/02/2022, 05:16:11
 * 
 * Image Information
 * -----------------
 * splash40.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPLASH40_H
#define SPLASH40_H

extern const unsigned short splash40[38400];
#define SPLASH40_SIZE 76800
#define SPLASH40_LENGTH 38400
#define SPLASH40_WIDTH 240
#define SPLASH40_HEIGHT 160

#endif

