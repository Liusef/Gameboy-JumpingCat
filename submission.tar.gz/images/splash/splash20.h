/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 splash20 splash20.png 
 * Time-stamp: Saturday 04/02/2022, 05:16:02
 * 
 * Image Information
 * -----------------
 * splash20.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPLASH20_H
#define SPLASH20_H

extern const unsigned short splash20[38400];
#define SPLASH20_SIZE 76800
#define SPLASH20_LENGTH 38400
#define SPLASH20_WIDTH 240
#define SPLASH20_HEIGHT 160

#endif

