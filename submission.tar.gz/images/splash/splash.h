/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 splash splash.png 
 * Time-stamp: Saturday 04/02/2022, 05:16:30
 * 
 * Image Information
 * -----------------
 * splash.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPLASH_H
#define SPLASH_H

extern const unsigned short splash[38400];
#define SPLASH_SIZE 76800
#define SPLASH_LENGTH 38400
#define SPLASH_WIDTH 240
#define SPLASH_HEIGHT 160

#endif

